/* BraIA64.c -- Converter for IA-64 code
2023-02-20 : Igor Pavlov : Public domain */

#include "Precomp.h"

// the code was moved to Bra.c

#ifdef _MSC_VER
#pragma warning(disable : 4206) // nonstandard extension used : translation unit is empty
#endif

#if defined(__clang__)
#pragma GCC diagnostic ignored "-Wempty-translation-unit"
#endif
